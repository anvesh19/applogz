#!/bin/bash
##########################################################################################
# INSTALL UPCUIMCLNT - Main Script, will divert to ubuntu/debian versions
##########################################################################################
export PATH="/sbin:/usr/local/sbin:/usr/sbin:/usr/local/bin:/usr/bin:/bin"

# locate binaries
cat=`which cat`
grep=`which grep`
wc=`which wc`
rpm=`which rpm`
cut=`which cut`
uname=`which uname`
sed=`which sed`

BASEDIR=/var/ldap/INSTALL 

echo ""
echo "[OS TYPE] "
echo ""

# check if /etc/lsb-release file exists
if [ -e "/etc/lsb-release" ]; then
 DISTIB_TYPE=`cat /etc/lsb-release |grep "DISTRIB_ID" |cut -d "=" -f 2`
 DISTRIB_RELEASE=`cat /etc/lsb-release | grep "DISTRIB_RELEASE" |cut -d "=" -f 2`
 echo " Found $DISTIB_TYPE $DISTRIB_RELEASE";
elif [ -e "/etc/debian_version" ]; then 
 DISTIB_TYPE="Debian"
 DISTRIB_RELEASE=`cat /etc/debian_version | cut -d "." -f 1`
else 
 echo " *) ERROR no /etc/lsb-release, no /etc/debian_version found, unknown OS !"
 exit -1
fi

if [ $DISTIB_TYPE == "Ubuntu" ]; then
 if [ $DISTRIB_RELEASE == "16.04" ]; then
    $BASEDIR/ubuntu_1604/init_hostname.sh
 elif [ $DISTRIB_RELEASE == "18.04" ]; then
    $BASEDIR/ubuntu_1804/init_hostname.sh
 elif [ $DISTRIB_RELEASE == "20.04" ]; then
    $BASEDIR/ubuntu_2004/init_hostname.sh
 elif [ $DISTRIB_RELEASE == "22.04" ]; then
    $BASEDIR/ubuntu_2204/init_hostname.sh
 else
   echo ""
   echo " Release is not supported or unknown"
   echo ""
 fi
elif [ $DISTIB_TYPE == "Debian" ]; then
 if [ $DISTRIB_RELEASE == "11" ]; then
    $BASEDIR/debian_11/init_hostname.sh
 elif [ $DISTRIB_RELEASE == "10" ]; then
    $BASEDIR/debian_10/init_hostname.sh
 elif [ $DISTRIB_RELEASE == "9" ]; then
    $BASEDIR/debian_9/init_hostname.sh
 elif [ $DISTRIB_RELEASE == "8" ]; then
    $BASEDIR/debian_8/init_hostname.sh
 elif [ $DISTRIB_RELEASE == "7" ]; then
    $BASEDIR/debian_7/init_hostname.sh
 else
   echo ""
   echo " Release is not supported or unknown"
   echo ""
 fi
else
 echo ""
 echo " Distribution is not supported or unknown"
 echo ""
 exit -1
fi
