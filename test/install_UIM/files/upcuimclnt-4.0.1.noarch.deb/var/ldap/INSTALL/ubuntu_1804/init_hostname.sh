#!/bin/bash
##############################################################################
# Version 2.2 - (c) Georg Swoboda, UPC Telekabel 2006-2019
#
# init ldap client, and do some basic checks to make sure it will work
# 2.1) Hostlist is fetched from solaris style profile
# 2.2) added support for dynamic server list
##############################################################################

# basedir
BASEDIR=/var/ldap/INSTALL/ubuntu_1804
SERVERLIST=/var/ldap/scripts/server.list
TESTCONN=/var/ldap/scripts/test_conn.sh
TESTNFS=/var/ldap/scripts/test_nfs.sh
UPDATE_SERVERLIST=/var/ldap/scripts/update_serverlist.sh
AUTOMOUNT=`which automount 2>/dev/null`

# locate binaries
cat=`which cat`
grep=`which grep`
wc=`which wc`
rpm=`which rpm`
cut=`which cut`
uname=`which uname`
sed=`which sed`
ldapsearch=`which ldapsearch`

hw=`$uname -i`
# fix broken hostnames (those with domains argh)
PROFILE_NAME=`$uname -n |$cut -d "." -f 1 | $sed -e 's/\(.*\)/\L\1/' `
SCODE=`echo $PROFILE_NAME | tr '[A-Z]' '[a-z]'  | awk '{print substr($1,1,3)}' `

#####################################################
# check_software.sh to see if install can work
#####################################################
echo ""
echo "[SOFTWARE CHECK]" 
echo ""
$BASEDIR/check_software.sh
if [ "$?" -ne 0 ]; then
 exit -1
fi

#####################################################
# update server list (from UIM servers)
#####################################################
$UPDATE_SERVERLIST
echo ""
echo "[HOSTS CHECK/SETUP] "
echo ""

####################################################
# flush all existing UIM hosts
####################################################
echo -n "  * flushing existing UIM hosts from /etc/hosts"
THOSTS="/tmp/hosts_$(basename $0).$$.tmp"
cat /etc/hosts |grep -v "puim" |grep -v "psrldap03" |grep -v "# - UIM Server -" > $THOSTS
mv $THOSTS /etc/hosts
echo "[OK]";

####################################################
# import server.list and update the hosts
# file - this is needed because we use hostnames
####################################################
exec < $SERVERLIST
while read line
do
  THIS_HOST=`echo $line |cut -d " " -f 2`
  THIS_IP=`echo $line |cut -d " " -f 1`
  LDAP_HOST_LIST="$LDAP_HOST_LIST $THIS_HOST"
  echo -n "  Checking for hostname '$THIS_HOST' in [/etc/hosts]"
  STATUS=`$cat /etc/hosts | $grep "$THIS_HOST" | $grep -v "^#" | $wc -c`
  if [ $STATUS -eq "0" ]; then
   echo "$THIS_IP   $THIS_HOST" >> /etc/hosts
   echo -n " Host entry appended"
  fi
  echo " [OK]"
done


####################################################
# test which ldap server is reachable for us
####################################################
echo ""
echo "[CONNECTIVITY CHECK] "
echo ""
unset WORKING_HOSTS
unset FOUND_HOST
for LDAP_HOST in $LDAP_HOST_LIST
do
  echo -n "  * testing $LDAP_HOST"
  $TESTCONN $LDAP_HOST 389
  if [ $? -eq "0" ]; then
   # we found a host to connect use it ...
   echo " [OK]"
   # add to list of working hosts
   WORKING_HOSTS="$WORKING_HOSTS $LDAP_HOST"
   if [ ! -n "$FOUND_HOST" ]; then
    # we pick the first host we can connect for the init of the client
    # and dont ever bother to test the others
    FOUND_HOST=$LDAP_HOST
   fi
  fi
done

if [ -n "$FOUND_HOST" ]; then
 echo ""
 echo "  * using ldap-server: $FOUND_HOST for client initialization"
 echo ""
fi

# check if we found at least one host that we can connect to
if [ ! -n "$FOUND_HOST" ]; then
 echo ""
 echo "   ================================================================="
 echo "   Unable to connect to any of the ldap servers ( $LDAP_HOST_LIST )"
 echo "   Please check connectivity to ldap servers and retry "
 echo "   ================================================================="
 echo ""
 exit -1
fi

#
# use the ldap server that we can connect to, to fetch the defaultserver list from the solaris profile
#
PROFILE_HOSTS=`ldapsearch -x -h $FOUND_HOST -b "ou=profile,dc=upc,dc=biz" "cn=$PROFILE_NAME" defaultserverlist |grep -i "defaultserverlist:" | awk '{print $2}' | sed s/"\,"/" "/g`
if [ -n "$PROFILE_HOSTS" ]; then
 echo "  * Profile Hosts: $PROFILE_HOSTS";
 WORKING_HOSTS="$PROFILE_HOSTS"
else
 echo "Unable to obtain defaultServerList from Profile";
 echo "Make sure there is a client profile for this host containing defaultServerList"
 exit -1
fi 
echo ""

#
# check if app client is installed, if so preserve configuration
#
echo "[CHECKING FOR APP CLIENT]"
echo ""
if [ -e /etc/ldap.conf ]; then
 CHECK=`cat /etc/ldap.conf  |grep "uimapp_" |wc -l`
  if [ $CHECK -gt "0" ]; then
    echo "  * AppClient is installed, preserving configuration"
    APP_TFILE="/tmp/$(basename $0).$$.tmp"
    cat /etc/ldap.conf | grep "uimapp_" > $APP_TFILE
  else
    echo "  * AppClient is not installed, nothing to preserve"
  fi
else
 echo "  * AppClient is not installed, nothing to preserve"
fi


#
# make backups of existing config files
#
echo ""
echo "[RECONFIGURING FOR LDAP]"
echo ""
echo -n "  * Backup and clean nsswitch.conf,ldap.conf,sudo-ldap.conf files"
if [ ! -e /etc/nsswitch.uim ]; then
  cp /etc/nsswitch.conf /etc/nsswitch.uim
fi
cp $BASEDIR/nsswitch.conf /etc/ 
echo -n " [nsswitch]"

if [ -e /etc/ldap.conf ]; then
 if [ ! -e /etc/ldap.uim ]; then
  cp /etc/ldap.conf /etc/ldap.uim
 fi
 rm /etc/ldap.conf
 echo -n " [ldap/1]"
fi

if [ -e /etc/ldap/ldap.conf ]; then
 if [ ! -e /etc/ldap/ldap.uim ]; then
  cp /etc/ldap/ldap.conf /etc/ldap/ldap.uim
 fi
 rm /etc/ldap/ldap.conf
 echo -n " [ldap/2]"
fi

if [ -e /etc/sudo-ldap.conf ]; then
 if [ ! -e /etc/sudo-ldap.uim ]; then
  cp /etc/sudo-ldap.conf /etc/sudo-ldap.uim
 fi
 rm /etc/sudo-ldap.conf
 echo -n " [sudo-ldap/1|"
fi

if [ -e /etc/nslcd.conf ]; then
 if [ ! -e /etc/nslcd.uim ]; then
  cp /etc/nslcd.conf /etc/nslcd.uim
 fi
 rm /etc/nslcd.conf
 echo -n " [sudo-ldap/1|"
fi
echo ""

echo -n "  * Backup /etc/pam.d files"
if [ ! -e /etc/pam.d/common-account.uim ]; then
  cp /etc/pam.d/common-account /etc/pam.d/common-account.uim
fi
if [ ! -e /etc/pam.d/common-auth.uim ]; then
  cp /etc/pam.d/common-auth /etc/pam.d/common-auth.uim
fi
if [ ! -e /etc/pam.d/common-password.uim ]; then
  cp /etc/pam.d/common-password /etc/pam.d/common-password.uim
fi
if [ ! -e /etc/pam.d/common-session.uim ]; then
  cp /etc/pam.d/common-session /etc/pam.d/common-session.uim
fi
if [ ! -e /etc/pam.d/common-session-noninteractive.uim ]; then
  cp /etc/pam.d/common-session-noninteractive /etc/pam.d/common-session-noninteractive.uim
fi

echo -n "  * Installing UIM enabled /etc/pam.d files"
cp $BASEDIR/common-* /etc/pam.d/

#################################################################
# generate the url list for nslcd.conf out of server.list
# WORKING_HOSTS contains a list of hostnames that we could connect
# to during the connectivity testing above
#################################################################
unset LDAPS_URL_LIST
for H in $WORKING_HOSTS
do
  LDAPS_URL_LIST="$LDAPS_URL_LIST ldaps://$H"
done
echo "" 
echo "  * Creating nslcd config ($LDAPS_URL_LIST) "
# we must sedify the url list because it contains slashes eek ..
LDAPS_URL_LIST=`echo $LDAPS_URL_LIST | sed s/"\\/"/"\\\\\\\\\\/"/g`
echo -n "  * using CORP filters"
cat $BASEDIR/nslcd.conf | sed s/_HOSTNAME_/"$PROFILE_NAME"/g | sed s/_SERVERLIST_/"$LDAPS_URL_LIST"/g  > /etc/nslcd.conf
echo -n "[nslcd/1] "
echo "[OK]"

#################################################################
# generate the url list for ldap.conf out of server.list
# WORKING_HOSTS contains a list of hostnames that we could connect
# to during the connectivity testing above
#################################################################
unset LDAPS_URL_LIST
for H in $WORKING_HOSTS
do
  LDAPS_URL_LIST="$LDAPS_URL_LIST ldaps://$H"
done
echo "  * Creating ldap config ($LDAPS_URL_LIST) "
# we must sedify the url list because it contains slashes eek ..
LDAPS_URL_LIST=`echo $LDAPS_URL_LIST | sed s/"\\/"/"\\\\\\\\\\/"/g`
echo -n "  * using CORP filters"
cat $BASEDIR/ldap.conf | sed s/_SERVERLIST_/"$LDAPS_URL_LIST"/g  > /etc/ldap.conf
echo -n "[ldap/1] "
echo "[OK]"

#
# generate sudo-ldap.conf and /etc/ldap/ldap.conf as symlinks
#
if [ ! -e  /etc/ldap/ldap.conf ]; then
 echo -n "  * Symlinking /etc/ldap.conf -> /etc/ldap/ldap.conf"
 ln -s /etc/ldap.conf /etc/ldap/ldap.conf
 echo "[OK]"
else
 rm /etc/ldap/ldap.conf
 ln -s /etc/ldap.conf /etc/ldap/ldap.conf
fi

if [ ! -e /etc/sudo-ldap.conf ]; then
 echo -n "  * Symlinking /etc/ldap.conf -> /etc/sudo-ldap.conf"
 ln -s /etc/ldap.conf /etc/sudo-ldap.conf
 echo "[OK]"
else
 rm /etc/sudo-ldap.conf
 ln -s /etc/ldap.conf /etc/sudo-ldap.conf
fi

#
# restore uim app config if saved before
#
if [ -n "$APP_TFILE" ]; then
 echo -n "  * Restoring APP Client config "
 cat $APP_TFILE >> /etc/ldap.conf
 echo "[OK"];
 rm $APP_TFILE
fi

#
# create /home_ldap
#
echo ""
echo "[CREATE LDAP CONFIG] "
echo ""
echo  -n "  * Making homedir for nfs mounts"
if [ -d /home_ldap ]; then
 echo -n " [already-existing] "
else
 mkdir -p /home_ldap
 echo -n " [created] "
fi
echo "[OK]"

echo "  * Stopping NSCD"
systemctl stop nscd 2> /dev/null
systemctl disable nscd 2> /dev/null

echo "  * Starting NSLCD"
systemctl restart nslcd 2> /dev/null
systemctl enable nslcd 2> /dev/null

#
# test our profile, make sure test user accounts are visible
#
echo ""
echo "[SELFTEST] "
echo ""
echo "  * Testing with the 'ldaptest' user"
su -s /bin/bash ldaptest
if [ "$?" -ne "0" ]; then
  echo "========================================================================
================================"
  echo "Please note the following information to get more support"
  echo "========================================================================
================================"=
  echo
  echo "========================================================================
================================"
  echo "= System Information"
  echo "========================================================================
================================"
  /bin/date
  /bin/uname -a
  /sbin/ifconfig -a
  echo "========================================================================
================================"
  echo
  echo "========================================================================
================================"
  echo "= /etc/hosts"
  echo "========================================================================
================================"
  /bin/cat /etc/hosts
  echo "========================================================================
================================"
  echo
  exit 1
fi

echo ""
echo "LDAP Client for Linux is installed SUCCESSFULLY"
echo ""
