#!/bin/bash

# check for the following packages
PKG_LIST="nslcd libkrb5-3 sudo-ldap libsasl2-2 ldap-utils libpam-ldap libnss-ldapd"
DPKG=`which dpkg`

FAIL=0
for P in $PKG_LIST
do
 $DPKG -S "$P" > /dev/null
 if [ "$?" -ne "0" ]; then
  echo " * Error: Package $P is not installed on this system !"
  FAIL=1
 fi
done
echo ""

if [ "$FAIL" -eq 1 ]; then
 echo ""
 echo "======================================================================================"
 echo " CAN NOT PROCCED with install because of missing packages, please install them first!"
 echo "======================================================================================"
 echo ""
else
 echo " * All packages required for UIM client found, good."
fi

exit $FAIL
