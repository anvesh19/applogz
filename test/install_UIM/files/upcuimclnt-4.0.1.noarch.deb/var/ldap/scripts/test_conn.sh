#!/bin/bash

#
# test_conn linux script
#
# test is done by using ldapsearch in timeout mode 
# against the ldap directory, trying to fetch the client profile
#

ldapsearch=`which ldapsearch`
uname=`which uname`
grep=`which grep`
cut=`which cut`
cat=`which cat`
sed=`which sed`
wc=`which wc`
cp=`which cp`
tr=`which tr`
awk=`which awk`
my_hostname=`$uname -n |cut -d "." -f 1`
my_os=`$uname -s`
PROFILES="ou=profile,dc=upc,dc=biz"
TIMELIMIT="5"

# check if ldapsearch supports -o nettimeout settings
CHECK_NTO=`$ldapsearch --help 2>&1 |grep nettimeout |wc -l`
if [ "$CHECK_NTO" = "1" ]; then
 LINUX_OPTION=" -o nettimeout=1 -x "
else
 LINUX_OPTION=" -x "
fi

function get_ldapSingleAttribute
{
 var=`$ldapsearch -LLL $LINUX_OPTION -H ldap://$HOST -l $TIMELIMIT  -b "$1" "$2" $3 | $grep -v "^#" | $grep $3 | $cut -d ":" -f 2 2>/dev/null`
 echo $var
}

####################################
# get profile attrbute
function get_profile_attribute
{
 var=`get_ldapSingleAttribute "$PROFILES" "cn=$my_hostname" "$1" 2>/dev/null`
 echo $var
}

####################################
# raw and ugly, but will work on non nettimeout clients
TimerOn()
{
 echo -n " [TESTING] "
 sleep $TIMELIMIT && echo "[TO_HIT on $$]" && kill -KILL $$ 2> /dev/null &
 # send sigalarm to ourself
}

#########################
# MAIN
#########################

HOST=$1
PORT=$2 # ignored for now

if [ "$CHECK_NTO" = "0" ]; then
TimerOn
fi

TEST=`get_profile_attribute defaultServerList`
if [ ! -n "$TEST" ]; then
 echo " [Unable to contact $HOST:389]"
 exit -1
fi

exit 0
