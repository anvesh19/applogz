#!/bin/bash
#
# Debian/Ubuntu UIM Installer
# (c) Georg Swoboda, 2019
#
#

SERVER_LIST="viepuimat10.cioio.net 84.116.3.60 uim.intern.upc.ch 172.25.47.138 viepuimat40.cioio.net 172.31.137.24 srbpuimnl40.cioio.net 172.31.133.12 uim.liberty.biz 172.31.138.154 uim.upc.biz 172.16.89.138 uim.upc.at 84.116.3.60 ecxpuimlg30 172.23.31.107 ecxpuimzg30 172.18.242.38 ecxpuimbe30 10.95.101.38 ecxpuimpl30 172.21.18.38 ecxpuimvt30 10.68.50.38 ecxpuimvm30 10.71.98.38 ecxpuimat30 172.18.98.38 ecxpuimie30 172.27.2.38 eclpuimlg30 172.23.83.32 eclpuimlc30 100.106.196.30 eclpuimsi30 172.23.66.30 nl-itclab-uim01 172.30.55.129 ocisuimpxyfr401 100.109.67.57 ocisuimpxynl401 100.109.67.71 ocisuimpxyuk401 100.107.16.185 awspuimprxec401 100.97.66.93 sr3suimconnllb601 100.104.70.150 sr4suimvlbnl401 100.104.25.5"

WGET=`which wget`
LATEST_FILE="/tmp/install_debian_latest"
INSTALL_FILE="/tmp/upcuimclnt.noarch.deb"


###############################################
# test if a download server is reachable
# return 0 on sucess, 1 on error
###############################################
function probe_server
{
 SERVER=$1 
 rm $LATEST_FILE
 echo -n "Probing for download server ($SERVER) " 
 $WGET --no-check-certificate -q -T 1 -t 1 https://$SERVER/download/upcuimclnt_noarch.deb.latest -O $LATEST_FILE
 if [ $? == "0" ]; then
  echo "[OK"]
  return 0
 else
  echo "[FAILED]"
  return 1
 fi
}

echo "" 
echo "=============================================================="
echo "= Debian/Ubuntu UIM Installer"
echo "=============================================================="
echo ""

for THIS_SERVER in $SERVER_LIST
do
 probe_server $THIS_SERVER
 ret_val=$?
 if [ $ret_val == "0" ]; then
  DOWNLOAD_SERVER=$THIS_SERVER
  break
 fi
done
if [ -z $DOWNLOAD_SERVER ]; then
 echo ""
 echo " ERROR: No working download server available, check connectivity !"
 echo ""
 sleep 2
 exit -1
fi

echo ""
echo -n "Finding newest release of upcuimclnt.noarch.deb " 
rm $LATEST_FILE
$WGET --no-check-certificate -T 5 -t 5 -q https://$DOWNLOAD_SERVER/download/upcuimclnt_noarch.deb.latest -O $LATEST_FILE
if [ -f $LATEST_FILE ]; then
 echo "[OK"]
else
 echo "[FAILED]"
 exit -1
fi

VER=`cat $LATEST_FILE`
PKG="upcuimclnt-$VER.noarch.deb"

echo -n "Downloading $PKG "
$WGET  --no-check-certificate -T 5 -t 5 -q https://$DOWNLOAD_SERVER/download/$PKG -O $INSTALL_FILE
if [ -f $INSTALL_FILE ]; then
 echo "[OK]" 
else
 echo "[FAILED]"
 exit -1 
fi

echo -n "Installing Package ... "
STATUS=`dpkg -i $INSTALL_FILE` 
if [ $? -eq "0" ]; then
 echo " [OK]"
else
 echo " [FAILED]";
 exit -1
fi

echo -n "Initializing LDAP Client"
STATUS=`/var/ldap/scripts/init_hostname.sh 2> /dev/null ` 
if [ $? -eq "0" ]; then
 echo " [OK]"
 echo -n "Removing Install Files ..."
 rm $INSTALL_FILE
 rm $LATEST_FILE
 echo "[DONE]"
else
 echo " [FAILED]";
 echo ""
 echo "The LDAP Client had trouble initializing the ldap_client,"
 echo "please run /var/ldap/scripts/init_hostname.sh to obtain"
 echo "a more detailed error description."
fi

echo ""
