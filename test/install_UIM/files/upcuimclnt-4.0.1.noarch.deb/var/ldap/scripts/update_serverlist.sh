##############################################################################
# Version 1.0 - (c) Georg Swoboda, UPC Telekabel 2006-2017
#
# this script updates server.list with the list of servers configured in UIM LDAP
# 
# 1. use existing server.list
# 2. probe for first reachable server
# 3. download available servers
# 4. probe available servers
# 5. add reachable servers to server.list
###############################################################################

SERVERLIST=/var/ldap/scripts/server.list
TESTCONN=/var/ldap/scripts/test_conn.sh

echo ""
echo "[UPDATING SERVER LIST] "
echo ""
####################################################
# import server.list (the hardcoded servers)
####################################################
unset LDAP_HOST_LIST
exec < $SERVERLIST
while read line
do
  THIS_HOST=`echo $line |cut -d " " -f 2`
  THIS_IP=`echo $line |cut -d " " -f 1`
  ##
  ## hostname based check
  ##
  echo -n "  * probing against hostname of $THIS_HOST ($THIS_IP)"
  $TESTCONN $THIS_HOST 389
  if [ $? -eq "0" ]; then
   # we found a host to connect use it ...
   echo " [OK]"
   if [ ! -n "$FOUND_HOST" ]; then
    # we pick the first host we can connect for the init of the client
    # and dont ever bother to test the others
    FOUND_HOST=$THIS_HOST
    break
   fi
  fi
  
  ##
  ## ip based check
  ##
  echo -n "  * probing against ip of $THIS_HOST ($THIS_IP)"
  $TESTCONN $THIS_IP 389
  if [ $? -eq "0" ]; then
   # we found a ip to connect use it ...
   echo " [OK]"
   if [ ! -n "$FOUND_HOST" ]; then
    # we pick the first host we can connect for the init of the client
    # and dont ever bother to test the others
    FOUND_HOST=$THIS_IP
    break
   fi
  fi
done

if [ -n "$FOUND_HOST" ]; then
 echo "  * using ldap-server: $FOUND_HOST to update UIM server list"
 echo ""
fi

####################################################################
# generate the server list that is used to initialize the client
####################################################################
DYN_SERVERLIST="$(ldapsearch -x -H ldap://$FOUND_HOST -b ou=servers,ou=config,dc=upc,dc=biz cn=* iphostnumber cn | egrep -i '^cn:|^iphostnumber:' | sed 's/^iphostnumber: /$/g'  | tr '\n' ' ' | sed 's/cn: //g' | tr '$' '\n' | sed '/^\s*$/d' && echo)"

#
# grab all hostnames from $DYN_SERVERLIST
#
TFILE="/tmp/$(basename $0).$$.tmp"
unset LDAP_HOST_LIST
while read -r line
do
  THIS_HOST=`echo $line |cut -d " " -f 2`
  THIS_IP=`echo $line |cut -d " " -f 1`
  echo -n "  * probing $THIS_HOST"
  $TESTCONN $THIS_IP 389
  if [ $? -eq "0" ]; then
    # we found a host to connect use it ...
    echo " [OK]"
    echo "$THIS_IP $THIS_HOST" >> $TFILE
  fi
done <<< "$DYN_SERVERLIST"

#
# move TFILE to SERVERLIST
#
mv $TFILE $SERVERLIST
echo ""

